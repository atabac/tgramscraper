﻿namespace TelegramBulkSender1
{
    partial class TelegramSender
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.appHashTextBox = new System.Windows.Forms.TextBox();
            this.appIDLabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.appIDTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.appHashLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.groupsPage = new System.Windows.Forms.TabPage();
            this.GetGroups = new System.Windows.Forms.Button();
            this.sendMessagePage = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.console = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.groupsPage.SuspendLayout();
            this.sendMessagePage.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.statusStrip1);
            this.splitContainer1.Panel2.Controls.Add(this.console);
            this.splitContainer1.Size = new System.Drawing.Size(1005, 741);
            this.splitContainer1.SplitterDistance = 591;
            this.splitContainer1.SplitterWidth = 8;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.appHashTextBox);
            this.splitContainer2.Panel1.Controls.Add(this.appIDLabel);
            this.splitContainer2.Panel1.Controls.Add(this.button2);
            this.splitContainer2.Panel1.Controls.Add(this.appIDTextBox);
            this.splitContainer2.Panel1.Controls.Add(this.button1);
            this.splitContainer2.Panel1.Controls.Add(this.appHashLabel);
            this.splitContainer2.Panel1.Controls.Add(this.textBox1);
            this.splitContainer2.Panel1.Controls.Add(this.phoneNumberLabel);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer2.Size = new System.Drawing.Size(1001, 587);
            this.splitContainer2.SplitterDistance = 181;
            this.splitContainer2.SplitterWidth = 8;
            this.splitContainer2.TabIndex = 8;
            // 
            // appHashTextBox
            // 
            this.appHashTextBox.Location = new System.Drawing.Point(131, 56);
            this.appHashTextBox.Name = "appHashTextBox";
            this.appHashTextBox.Size = new System.Drawing.Size(514, 27);
            this.appHashTextBox.TabIndex = 3;
            // 
            // appIDLabel
            // 
            this.appIDLabel.AutoSize = true;
            this.appIDLabel.Location = new System.Drawing.Point(17, 23);
            this.appIDLabel.Name = "appIDLabel";
            this.appIDLabel.Size = new System.Drawing.Size(56, 20);
            this.appIDLabel.TabIndex = 1;
            this.appIDLabel.Text = "App ID";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(117, 128);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 7;
            this.button2.Text = "Disconnect";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // appIDTextBox
            // 
            this.appIDTextBox.Location = new System.Drawing.Point(131, 23);
            this.appIDTextBox.Name = "appIDTextBox";
            this.appIDTextBox.Size = new System.Drawing.Size(514, 27);
            this.appIDTextBox.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 6;
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // appHashLabel
            // 
            this.appHashLabel.AutoSize = true;
            this.appHashLabel.Location = new System.Drawing.Point(17, 56);
            this.appHashLabel.Name = "appHashLabel";
            this.appHashLabel.Size = new System.Drawing.Size(74, 20);
            this.appHashLabel.TabIndex = 2;
            this.appHashLabel.Text = "App Hash";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(131, 89);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(514, 27);
            this.textBox1.TabIndex = 5;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(17, 89);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(108, 20);
            this.phoneNumberLabel.TabIndex = 4;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.groupsPage);
            this.tabControl1.Controls.Add(this.sendMessagePage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1001, 398);
            this.tabControl1.TabIndex = 0;
            // 
            // groupsPage
            // 
            this.groupsPage.Controls.Add(this.GetGroups);
            this.groupsPage.Location = new System.Drawing.Point(4, 29);
            this.groupsPage.Name = "groupsPage";
            this.groupsPage.Padding = new System.Windows.Forms.Padding(3);
            this.groupsPage.Size = new System.Drawing.Size(993, 365);
            this.groupsPage.TabIndex = 0;
            this.groupsPage.Text = "Groups";
            this.groupsPage.UseVisualStyleBackColor = true;
            // 
            // GetGroups
            // 
            this.GetGroups.Location = new System.Drawing.Point(16, 14);
            this.GetGroups.Name = "GetGroups";
            this.GetGroups.Size = new System.Drawing.Size(94, 29);
            this.GetGroups.TabIndex = 0;
            this.GetGroups.Text = "Get Groups";
            this.GetGroups.UseVisualStyleBackColor = true;
            // 
            // sendMessagePage
            // 
            this.sendMessagePage.Controls.Add(this.textBox2);
            this.sendMessagePage.Controls.Add(this.sendButton);
            this.sendMessagePage.Location = new System.Drawing.Point(4, 29);
            this.sendMessagePage.Name = "sendMessagePage";
            this.sendMessagePage.Padding = new System.Windows.Forms.Padding(3);
            this.sendMessagePage.Size = new System.Drawing.Size(993, 398);
            this.sendMessagePage.TabIndex = 1;
            this.sendMessagePage.Text = "Send Message";
            this.sendMessagePage.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox2.Location = new System.Drawing.Point(3, 3);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(638, 392);
            this.textBox2.TabIndex = 1;
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(647, 6);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(94, 29);
            this.sendButton.TabIndex = 0;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 112);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1001, 26);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(52, 20);
            this.toolStripStatusLabel1.Text = "Status:";
            // 
            // console
            // 
            this.console.Dock = System.Windows.Forms.DockStyle.Fill;
            this.console.Location = new System.Drawing.Point(0, 0);
            this.console.Multiline = true;
            this.console.Name = "console";
            this.console.Size = new System.Drawing.Size(1001, 138);
            this.console.TabIndex = 0;
            // 
            // TelegramSender
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 741);
            this.Controls.Add(this.splitContainer1);
            this.Name = "TelegramSender";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.groupsPage.ResumeLayout(false);
            this.sendMessagePage.ResumeLayout(false);
            this.sendMessagePage.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SplitContainer splitContainer1;
        private TabControl tabControl1;
        private TabPage groupsPage;
        private Button GetGroups;
        private TextBox appHashTextBox;
        private Label appHashLabel;
        private Label appIDLabel;
        private TextBox appIDTextBox;
        private TextBox textBox1;
        private Label phoneNumberLabel;
        private Button button2;
        private Button button1;
        private SplitContainer splitContainer2;
        private TextBox console;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private TabPage sendMessagePage;
        private Button sendButton;
        private TextBox textBox2;
    }
}